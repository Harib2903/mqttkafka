package com.mqttkafka.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mqttkafka.app.models.MqttSubscribeModel;

import com.mqttkafka.app.utlis.Mqtt;




@Service
public class MqttConsumer {
	private static final Logger LOGGER=LoggerFactory.getLogger(MqttConsumer.class);
	@Autowired
	KafkaProducer kafkaProducer;
	
	
	
	public List<MqttSubscribeModel> subscribeChannel( String topic,String message, Integer waitMillis)
			throws InterruptedException, org.eclipse.paho.client.mqttv3.MqttException {
		List<MqttSubscribeModel> messages = new ArrayList<>();
		CountDownLatch countDownLatch = new CountDownLatch(10);
		Mqtt.getInstance().subscribeWithResponse(topic, (s, mqttMessage) -> {
			MqttSubscribeModel mqttSubscribeModel = new MqttSubscribeModel();
			mqttSubscribeModel.setId(mqttMessage.getId());
			mqttSubscribeModel.setMessage(new String(mqttMessage.getPayload()));
			mqttSubscribeModel.setQos(mqttMessage.getQos());
			messages.add(mqttSubscribeModel);
			countDownLatch.countDown();
			LOGGER.info(String.format("Message received  mqttComsumer -> %s", mqttMessage));
			LOGGER.info(String.format("Message send from  mqttComsumer to kafkaProducer -> %s", mqttMessage));
			
			
		});
		
		
		return messages;
	}


}
