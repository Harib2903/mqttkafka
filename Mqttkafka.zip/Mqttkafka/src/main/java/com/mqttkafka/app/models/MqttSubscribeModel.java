package com.mqttkafka.app.models;

public class MqttSubscribeModel {
	 private String message;
	 private Integer qos;
	 private Integer Id;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Integer getQos() {
		return qos;
	}
	public void setQos(Integer qos) {
		this.qos = qos;
	}
	public Integer getId() {
		return Id;
	}
	public void setId(Integer id) {
		Id = id;
	}
	@Override
	public String toString() {
		return "MqttSubscribeModel [message=" + message + ", qos=" + qos + ", Id=" + Id + "]";
	}
	 
	 

}
