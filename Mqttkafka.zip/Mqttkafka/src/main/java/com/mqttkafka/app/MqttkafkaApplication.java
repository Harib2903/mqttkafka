package com.mqttkafka.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.TaskExecutor;

@SpringBootApplication
public class MqttkafkaApplication {
	@Autowired
	private Runnable mqttListener;

	public static void main(String[] args) {
		SpringApplication.run(MqttkafkaApplication.class, args);
	}
	

	@Bean
	public CommandLineRunner schedulingRunner(@Qualifier("applicationTaskExecutor")TaskExecutor executor) {
		return new CommandLineRunner() {
			public void run(String... args) throws Exception {
				executor.execute(mqttListener);
			}
		};
	}

}
