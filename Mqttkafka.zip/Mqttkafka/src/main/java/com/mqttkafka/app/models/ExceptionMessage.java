package com.mqttkafka.app.models;

public class ExceptionMessage {
	public static final Throwable SOME_PARAMETERS_INVALID = null;

}
