package com.mqttkafka.app.service;

import java.util.List;

import org.eclipse.paho.client.mqttv3.MqttException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mqttkafka.app.models.MqttSubscribeModel;

@Component
public class MqttListener implements Runnable {
	private static final Logger LOGGER = LoggerFactory.getLogger(MqttListener.class);

	@Autowired
	MqttConsumer subscriber;

	@Autowired
	KafkaProducer kafkaProducer;

	@Override
	public void run() {
		List<MqttSubscribeModel> messages=null;
		try {
			messages = subscriber.subscribeChannel("test","hello", 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MqttException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

			System.out.println(messages+"- received messae");
			
			if (messages.size() > 0) {
				LOGGER.info(String.format("sending to kafka Producer ->" +messages));
				System.out.println("sending to kafka Produce");
				//kafkaProducer.sendMessage(messages);
			}
	}
}
