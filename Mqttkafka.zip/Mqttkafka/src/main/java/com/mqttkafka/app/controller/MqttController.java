package com.mqttkafka.app.controller;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mqttkafka.app.models.ExceptionMessage;
import com.mqttkafka.app.models.MqttPublishModel;
import com.mqttkafka.app.service.KafkaProducer;
import com.mqttkafka.app.service.MqttConsumer;
import com.mqttkafka.app.utlis.Mqtt;

@RestController
@RequestMapping(value = "/api/mqtt")
public class MqttController {
	// http://localhost:8080//api/mqtt/publish

	@Autowired
	KafkaProducer kafkaProducer;

	private static final Logger LOGGER = LoggerFactory.getLogger(MqttController.class);

	@PostMapping("publish")
	public void publishMessage(@RequestBody @Validated MqttPublishModel messagePublishModel,
			BindingResult bindingResult) throws org.eclipse.paho.client.mqttv3.MqttException {
		if (bindingResult.hasErrors()) {
			throw new MqttException(ExceptionMessage.SOME_PARAMETERS_INVALID);
		}

		MqttMessage mqttMessage = new MqttMessage(messagePublishModel.getMessage().getBytes());
		mqttMessage.setQos(messagePublishModel.getQos());
		mqttMessage.setRetained(messagePublishModel.getRetained());

		Mqtt.getInstance().publish(messagePublishModel.getTopic(), mqttMessage);
		LOGGER.info(String.format("Message Send from MqttProducerController ->%s", mqttMessage));

	}

	@GetMapping("subscribe")
	public List<MqttConsumer> subscribeMessage( @RequestParam(value="topic")String topic,@RequestParam(value="message") String message,
			@RequestParam(value = "wait_millis") Integer waitMillis)
			throws InterruptedException, org.eclipse.paho.client.mqttv3.MqttException {
		List<MqttConsumer> messages = new ArrayList<>();
		MqttConsumer mqttConsumer = new MqttConsumer();
		mqttConsumer.subscribeChannel(topic, message, waitMillis);
		messages.add(mqttConsumer);
		kafkaProducer.sendMessage(message);
		return messages;
	}

//	@GetMapping("subscribe1")
//    public List<MqttConsumer> subscribeMessage1(@RequestBody @Validated MqttPublishModel messagePublishModel,
//    		BindingResult bindingResult, @RequestParam(value = "wait_millis") Integer waitMillis)
//            throws InterruptedException, org.eclipse.paho.client.mqttv3.MqttException {
//		
//
//		
//		List<MqttConsumer> messages = new ArrayList<>();
//		MqttConsumer mqttConsumerr=new MqttConsumer();
//		
//		MqttPublishModel mqttConsumer = new MqttPublishModel();
//		mqttConsumer.setMessage(messagePublishModel.getMessage());
//		mqttConsumerr.subscribeChannel(messagePublishModel.getTopic(), waitMillis);
//		kafkaProducer.sendMessage(messagePublishModel.getMessage());
//		
//		
//		System.out.println("Hello" +	messagePublishModel.getMessage() );
//		
//		return messages;
//		
//   }
}
