package com.mqttkafka.app.utlis;

public class KafkaAppConstants {
	public static final String TOPIC_NAME = "test";
	public static final String GROUP_ID = "mygroup";

}
